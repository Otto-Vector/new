<?php
    if ($_POST["login"] == "admin") echo "error";
    if ($_POST["login"] == "ottovector") echo "error";
    if ($_POST["login"] == "otto") echo "error";
    if ($_POST["login"] == "vector") echo "error";
?>